# my-mini-blog
My version of mini blog for biocad internship
